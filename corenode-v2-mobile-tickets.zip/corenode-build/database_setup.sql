-- ═══════════════════════════════════════════════════════════════════════
--  CoreNode Hosting Platform – Supabase Database Setup
--  Run ALL of this in your Supabase SQL Editor:
--  https://supabase.com/dashboard/project/YOUR_PROJECT_ID/sql
--
--  This script is idempotent – safe to run multiple times.
-- ═══════════════════════════════════════════════════════════════════════


-- ── STEP 1: PROFILES TABLE ──────────────────────────────────────────────
-- Stores user roles (user | admin). Auto-created on signup via trigger.

CREATE TABLE IF NOT EXISTS profiles (
  id         UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email      TEXT,
  role       TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Users can read their own profile
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;
CREATE POLICY "Users can read own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

-- Users can insert their own profile (needed for signup)
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Service role can manage all profiles (backend uses service role key)
DROP POLICY IF EXISTS "Service role manages profiles" ON profiles;
CREATE POLICY "Service role manages profiles" ON profiles
  USING (true) WITH CHECK (true);

-- Grant access
GRANT SELECT, INSERT, UPDATE ON profiles TO anon, authenticated;


-- ── STEP 2: AUTO-CREATE PROFILE ON SIGNUP ──────────────────────────────
-- This trigger runs every time a new user signs up in Supabase Auth.

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, role)
  VALUES (NEW.id, NEW.email, 'user')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- ── STEP 3: ORDERS TABLE ───────────────────────────────────────────────
-- Stores all customer orders. Status: Pending → Approved | Rejected

CREATE TABLE IF NOT EXISTS orders (
  id               BIGSERIAL PRIMARY KEY,
  user_id          UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  plan_name        TEXT NOT NULL,
  plan_type        TEXT,
  price            NUMERIC(10,2) NOT NULL DEFAULT 0,
  utr              TEXT,
  customer_name    TEXT,
  customer_email   TEXT,
  status           TEXT NOT NULL DEFAULT 'Pending'
                     CHECK (status IN ('Pending', 'Approved', 'Rejected')),
  panel_link       TEXT,
  panel_username   TEXT,
  panel_password   TEXT,
  approved_at      TIMESTAMPTZ,
  admin_note       TEXT,
  email_sent       BOOLEAN NOT NULL DEFAULT false,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for fast lookups
CREATE INDEX IF NOT EXISTS idx_orders_user_id  ON orders (user_id);
CREATE INDEX IF NOT EXISTS idx_orders_status   ON orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_created  ON orders (created_at DESC);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Users can see only their own orders
DROP POLICY IF EXISTS "Users see own orders" ON orders;
CREATE POLICY "Users see own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

-- Users can insert their own orders
DROP POLICY IF EXISTS "Users insert own orders" ON orders;
CREATE POLICY "Users insert own orders" ON orders
  FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Service role (backend) can do everything
DROP POLICY IF EXISTS "Service role full access on orders" ON orders;
CREATE POLICY "Service role full access on orders" ON orders
  USING (true) WITH CHECK (true);

-- Grant access
GRANT ALL ON orders TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE orders_id_seq TO anon, authenticated;


-- ── STEP 4: TICKETS TABLE ─────────────────────────────────────────────
-- Support tickets submitted by users.

CREATE TABLE IF NOT EXISTS tickets (
  id              BIGSERIAL PRIMARY KEY,
  user_id         UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  subject         TEXT,
  message         TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'Open'
                    CHECK (status IN ('Open', 'Replied', 'Answered', 'Closed')),
  admin_reply     TEXT,
  order_ref       TEXT,
  customer_email  TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_tickets_user_id ON tickets (user_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status  ON tickets (status);
CREATE INDEX IF NOT EXISTS idx_tickets_created ON tickets (created_at DESC);

ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users see own tickets" ON tickets;
CREATE POLICY "Users see own tickets" ON tickets
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users insert own tickets" ON tickets;
CREATE POLICY "Users insert own tickets" ON tickets
  FOR INSERT WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

DROP POLICY IF EXISTS "Service role full access on tickets" ON tickets;
CREATE POLICY "Service role full access on tickets" ON tickets
  USING (true) WITH CHECK (true);

GRANT ALL ON tickets TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE tickets_id_seq TO anon, authenticated;


-- ── STEP 5: PLANS TABLE ────────────────────────────────────────────────
-- Hosting plans displayed on the frontend (Minecraft, VPS, etc.)

CREATE TABLE IF NOT EXISTS plans (
  id          BIGSERIAL PRIMARY KEY,
  plan_id     TEXT UNIQUE,
  name        TEXT NOT NULL,
  plan_type   TEXT DEFAULT 'Minecraft Hosting',
  node        TEXT DEFAULT 'amd',
  ram         TEXT,
  vcores      INTEGER,
  nvme        TEXT,
  bandwidth   TEXT,
  backups     INTEGER DEFAULT 1,
  price       NUMERIC(10,2) NOT NULL DEFAULT 0,
  stock       INTEGER NOT NULL DEFAULT 10,
  tag         TEXT,
  deleted     BOOLEAN NOT NULL DEFAULT false,
  sort_order  INTEGER DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Plans are public" ON plans;
CREATE POLICY "Plans are public" ON plans
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Service role manages plans" ON plans;
CREATE POLICY "Service role manages plans" ON plans
  USING (true) WITH CHECK (true);

GRANT SELECT ON plans TO anon, authenticated;
GRANT USAGE, SELECT ON SEQUENCE plans_id_seq TO anon, authenticated;


-- ── STEP 6: SETTINGS TABLE ────────────────────────────────────────────
-- Stores payment QR code and UPI ID (admin-configurable).

CREATE TABLE IF NOT EXISTS settings (
  id         INTEGER PRIMARY KEY DEFAULT 1,
  qr_image   TEXT DEFAULT 'assets/images/payment-qr.png',
  upi_id     TEXT DEFAULT 'payments@corenode.in',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default row (only one row needed, id=1)
INSERT INTO settings (id, qr_image, upi_id)
VALUES (1, 'assets/images/payment-qr.png', 'payments@corenode.in')
ON CONFLICT (id) DO NOTHING;

ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Settings are public" ON settings;
CREATE POLICY "Settings are public" ON settings
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Service role manages settings" ON settings;
CREATE POLICY "Service role manages settings" ON settings
  USING (true) WITH CHECK (true);

GRANT SELECT ON settings TO anon, authenticated;


-- ── STEP 7: SET YOUR ADMIN ACCOUNT ────────────────────────────────────
-- After signing up, run this to grant yourself admin access.
-- Replace 'admin@yourdomain.com' with your actual admin email.
--
-- UPDATE profiles SET role = 'admin' WHERE email = 'admin@yourdomain.com';


-- ═══════════════════════════════════════════════════════════════════════
--  VERIFICATION QUERIES
--  Run these to confirm everything was created correctly:
-- ═══════════════════════════════════════════════════════════════════════

-- SELECT table_name FROM information_schema.tables
--   WHERE table_schema = 'public'
--   ORDER BY table_name;

-- SELECT * FROM profiles LIMIT 5;
-- SELECT * FROM orders LIMIT 5;
-- SELECT * FROM tickets LIMIT 5;
-- SELECT * FROM settings;
