# CoreNode Hosting Platform

A full-stack SaaS hosting platform with Supabase Auth, Express.js backend, and vanilla JS frontend.

---

## Architecture

```
User Browser  ──→  Frontend (HTML/CSS/JS)
                        │
                        ▼  POST/GET via fetch() + Supabase JWT
                   Backend (Express.js :5000)
                        │
                        ▼  Service Role Key (bypasses RLS)
                   Supabase (PostgreSQL + Auth)
```

**Flow:** User logs in → cart → checkout → `POST /api/orders/create` → DB row (Pending) → admin approves → `POST /api/orders/approve` → DB updated (Approved + credentials) → user dashboard shows panel URL, username, password.

---

## Quick Start

### Prerequisites
- Node.js v18+
- A Supabase project (free tier works)

### 1. Install backend dependencies

```bash
cd backend
npm install
```

### 2. Configure environment

```bash
cp .env.example .env
```

Edit `.env` and fill in:

| Variable | Where to find it |
|---|---|
| `SUPABASE_URL` | Supabase dashboard → Settings → API → Project URL |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase dashboard → Settings → API → service_role secret |

### 3. Configure frontend Supabase credentials

Edit `assets/js/supabase.js` — update these two lines:

```js
const SUPABASE_URL  = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON = 'your_anon_public_key_here';
```

Find these in Supabase → Settings → API → `anon` `public` key.

### 4. Run database setup

1. Open your Supabase project dashboard
2. Go to **SQL Editor**
3. Paste the entire contents of `database_setup.sql`
4. Click **Run**

This creates: `profiles`, `orders`, `tickets`, `plans`, `settings` tables with RLS policies and the auto-profile trigger.

### 5. Start the backend

```bash
cd backend
npm start
# or for auto-reload during development:
npm run dev
```

The server starts at **http://localhost:5000**

The frontend is automatically served from the same port — open http://localhost:5000 in your browser.

### 6. Create your admin account

1. Sign up at http://localhost:5000/signup.html
2. In Supabase SQL Editor, run:

```sql
UPDATE profiles SET role = 'admin' WHERE email = 'your@email.com';
```

3. Log in — the admin dashboard is at http://localhost:5000/admin-dashboard.html

---

## Testing the Full Flow

### Step 1 — User signup & login
- Go to `/signup.html`, create an account
- Verify you receive a confirmation email (if enabled) or auto-login

### Step 2 — Add to cart & checkout
- Browse plans on `/minecraft.html` or `/vps.html`
- Click **Add to Cart** on any plan
- Click the cart icon → **Checkout**
- Fill in: Full Name, Email, and any 6+ digit UTR (use `123456` for testing)
- Click **Submit Payment**
- You should be redirected to `/dashboard.html`

### Step 3 — Verify order in database
In Supabase SQL Editor:
```sql
SELECT id, plan_name, status, utr, customer_email FROM orders ORDER BY created_at DESC LIMIT 5;
```
You should see a row with `status = 'Pending'`.

### Step 4 — Admin approves the order
- Log in as admin, go to `/admin-dashboard.html`
- Find the pending order, click **🚀 Approve**
- Fill in: Panel URL, Username, Password (or use **Auto-Generate**)
- Click **Confirm & Provision**

### Step 5 — Verify approval in database
```sql
SELECT id, status, panel_link, panel_username, panel_password FROM orders WHERE status = 'Approved';
```

### Step 6 — User sees credentials
- Log in as the user
- Go to `/dashboard.html`
- The order should show **Approved** with Panel URL, Username, and Password visible

---

## API Reference

All endpoints require `Authorization: Bearer <supabase_access_token>` header.

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/orders/create` | User | Create new order |
| GET | `/api/orders/user/:userId` | User | Get user's orders |
| GET | `/api/orders/admin` | Admin | Get all orders |
| POST | `/api/orders/approve` | Admin | Approve + provision order |
| POST | `/api/orders/reject` | Admin | Reject order |
| POST | `/api/tickets/create` | User | Create support ticket |
| GET | `/api/tickets/user/:userId` | User | Get user's tickets |
| GET | `/api/tickets/admin` | Admin | Get all tickets |
| POST | `/api/tickets/reply` | Admin | Reply to ticket |
| DELETE | `/api/tickets/:id` | Admin | Delete ticket |
| GET | `/health` | None | Server health check |

---

## Project Structure

```
corenode/
├── assets/
│   ├── css/styles.css          # All styles + mobile responsive
│   └── js/
│       ├── supabase.js         # Supabase client, AuthManager, DB object
│       ├── api.js              # Backend API client + DB shim
│       ├── cart.js             # Shopping cart
│       ├── checkout.js         # Checkout modal + order creation
│       ├── auto-provision.js   # Admin approval pipeline
│       ├── navbar-auth.js      # Auth-aware navbar (calls DB_connectBackend)
│       ├── admin.js            # Admin auth guard
│       ├── support.js          # Ticket system
│       ├── settings.js         # Admin settings
│       └── orders.js           # Orders page
├── backend/
│   ├── server.js               # Express server
│   ├── routes/
│   │   ├── orders.js
│   │   └── tickets.js
│   ├── controllers/
│   │   ├── ordersController.js
│   │   └── ticketsController.js
│   ├── middleware/
│   │   └── authMiddleware.js   # JWT verification + admin check
│   ├── config/
│   │   └── supabase.js         # Service role client
│   ├── .env.example
│   └── package.json
├── config/pricing.js           # Plan pricing data
├── database_setup.sql          # Complete DB schema (run in Supabase)
├── index.html
├── minecraft.html
├── vps.html
├── dashboard.html
├── admin-dashboard.html
├── login.html
├── signup.html
└── orders.html
```

---

## Bugs Fixed in This Version

| Bug | Root Cause | Fix |
|---|---|---|
| `AutoProvision is not defined` | `auto-provision.js` had the entire module copy-pasted twice, breaking the IIFE | Removed duplicate code; single clean module |
| Checkout creates no orders | `checkout.js` also had duplicate IIFE code AND missing API call for logged-in users | Rewrote with clean priority: API → Supabase → localStorage |
| Reject button broken | `updateOrderStatus('Rejected')` called `saveOrderUpdate` which had no direct Supabase path | Now calls `AutoProvision.reject()` which uses `/api/orders/reject` |
| Backend not used on plan pages | `DB_connectBackend()` was only called on dashboard pages, not on `minecraft.html`, `vps.html`, `index.html` | `navbar-auth.js` now calls `DB_connectBackend()` on every page |
| Modal cut off on mobile | `align-items: center` on overlay with tall modals on small screens | Changed to `align-items: flex-start` + `overflow-y: auto` on overlay |
| Admin `AutoProvision.reject()` missing | The function only had `approve()` | Added `reject()` with API → direct Supabase fallback |
