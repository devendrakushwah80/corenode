/**
 * controllers/ordersController.js
 * ─────────────────────────────────────────────────────────────────
 * Business logic for all order-related operations.
 *
 * Tables used:
 *   orders   – main order records
 *   plans    – stock decrement on order create (optional, graceful)
 */

const supabase = require('../config/supabase');

/* ─────────────────────────────────────────────────────────────────
   POST /api/orders/create
   Auth: requireAuth
   Creates a new order with status = 'Pending'.
───────────────────────────────────────────────────────────────── */
async function createOrder(req, res) {
  const { plan_name, plan_type, price, utr, customer_name, customer_email } = req.body;
  const user_id = req.user.id;

  // ── Validate required fields ──────────────────────────────────
  if (!plan_name || !price || !utr) {
    return res.status(400).json({
      success: false,
      error: 'Missing required fields: plan_name, price, utr',
    });
  }

  if (isNaN(Number(price)) || Number(price) <= 0) {
    return res.status(400).json({
      success: false,
      error: 'price must be a positive number',
    });
  }

  if (String(utr).length < 6) {
    return res.status(400).json({
      success: false,
      error: 'utr must be at least 6 characters',
    });
  }

  // ── Insert order ──────────────────────────────────────────────
  const orderPayload = {
    user_id,
    plan_name: String(plan_name).trim(),
    plan_type: plan_type ? String(plan_type).trim() : null,
    price:     Number(price),
    utr:       String(utr).trim(),
    customer_name:  customer_name  ? String(customer_name).trim()  : null,
    customer_email: customer_email ? String(customer_email).trim() : req.user.email,
    status:        'Pending',
    panel_link:    null,
    panel_username: null,
    panel_password: null,
  };

  const { data, error } = await supabase
    .from('orders')
    .insert([orderPayload])
    .select()
    .single();

  if (error) {
    console.error('[Orders] createOrder error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to create order. Please try again.',
      detail: error.message,
    });
  }

  return res.status(201).json({
    success: true,
    message: 'Order created successfully',
    order: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   GET /api/orders/user/:userId
   Auth: requireAuth
   Returns orders for the authenticated user.
   Users can only access their own orders.
───────────────────────────────────────────────────────────────── */
async function getUserOrders(req, res) {
  const requestedUserId = req.params.userId;
  const authenticatedUserId = req.user.id;

  // Security: regular users can only fetch their own orders
  // Admins can fetch any user's orders (role checked by requireAdmin)
  if (requestedUserId !== authenticatedUserId && req.userRole !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'You can only view your own orders.',
    });
  }

  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('user_id', requestedUserId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('[Orders] getUserOrders error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to fetch orders.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    count: data.length,
    orders: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   GET /api/orders/admin
   Auth: requireAdmin
   Returns ALL orders (admin only).
───────────────────────────────────────────────────────────────── */
async function getAllOrders(req, res) {
  const { status, limit = 100, offset = 0 } = req.query;

  let query = supabase
    .from('orders')
    .select('*')
    .order('created_at', { ascending: false })
    .range(Number(offset), Number(offset) + Number(limit) - 1);

  // Optional filter by status
  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) {
    console.error('[Orders] getAllOrders error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to fetch orders.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    count: data.length,
    orders: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   POST /api/orders/approve
   Auth: requireAdmin
   Admin approves an order: sets panel details + status = 'Approved'.
   Body: { id, panel_link, panel_username, panel_password, admin_note? }
───────────────────────────────────────────────────────────────── */
async function approveOrder(req, res) {
  const { id, panel_link, panel_username, panel_password, admin_note } = req.body;

  if (!id) {
    return res.status(400).json({
      success: false,
      error: 'Order id is required.',
    });
  }

  if (!panel_link || !panel_username || !panel_password) {
    return res.status(400).json({
      success: false,
      error: 'Missing required fields: panel_link, panel_username, panel_password',
    });
  }

  // Verify order exists
  const { data: existingOrder, error: fetchError } = await supabase
    .from('orders')
    .select('id, status')
    .eq('id', id)
    .single();

  if (fetchError || !existingOrder) {
    return res.status(404).json({
      success: false,
      error: `Order with id ${id} not found.`,
    });
  }

  if (existingOrder.status === 'Approved') {
    return res.status(409).json({
      success: false,
      error: 'Order is already approved.',
    });
  }

  // Update order
  const updatePayload = {
    status:         'Approved',
    panel_link:     String(panel_link).trim(),
    panel_username: String(panel_username).trim(),
    panel_password: String(panel_password).trim(),
    approved_at:    new Date().toISOString(),
  };

  if (admin_note) {
    updatePayload.admin_note = String(admin_note).trim();
  }

  const { data, error } = await supabase
    .from('orders')
    .update(updatePayload)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('[Orders] approveOrder error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to approve order.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    message: `Order #${id} approved successfully`,
    order: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   POST /api/orders/reject
   Auth: requireAdmin
   Reject a pending order.
   Body: { id, admin_note? }
───────────────────────────────────────────────────────────────── */
async function rejectOrder(req, res) {
  const { id, admin_note } = req.body;

  if (!id) {
    return res.status(400).json({ success: false, error: 'Order id is required.' });
  }

  const updatePayload = {
    status: 'Rejected',
    approved_at: null,
  };

  if (admin_note) updatePayload.admin_note = String(admin_note).trim();

  const { data, error } = await supabase
    .from('orders')
    .update(updatePayload)
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('[Orders] rejectOrder error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to reject order.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    message: `Order #${id} rejected`,
    order: data,
  });
}

module.exports = {
  createOrder,
  getUserOrders,
  getAllOrders,
  approveOrder,
  rejectOrder,
};
