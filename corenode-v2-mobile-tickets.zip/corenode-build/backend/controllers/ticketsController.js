/**
 * controllers/ticketsController.js
 * ─────────────────────────────────────────────────────────────────
 * Business logic for all support ticket operations.
 *
 * Tables used:
 *   tickets  – support ticket records
 *   profiles – role check cache (handled by middleware)
 */

const supabase = require('../config/supabase');

/* ─────────────────────────────────────────────────────────────────
   POST /api/tickets/create
   Auth: requireAuth
   Creates a new support ticket with status = 'Open'.
   Body: { subject, message, order_ref? }
───────────────────────────────────────────────────────────────── */
async function createTicket(req, res) {
  const { subject, message, order_ref } = req.body;
  const user_id = req.user.id;
  const customer_email = req.user.email;

  if (!message || String(message).trim().length < 10) {
    return res.status(400).json({
      success: false,
      error: 'message is required and must be at least 10 characters.',
    });
  }

  if (!subject || String(subject).trim().length < 3) {
    return res.status(400).json({
      success: false,
      error: 'subject is required and must be at least 3 characters.',
    });
  }

  const ticketPayload = {
    user_id,
    customer_email,
    subject:    String(subject).trim(),
    message:    String(message).trim(),
    order_ref:  order_ref ? String(order_ref).trim() : null,
    status:     'Open',
    admin_reply: null,
  };

  const { data, error } = await supabase
    .from('tickets')
    .insert([ticketPayload])
    .select()
    .single();

  if (error) {
    console.error('[Tickets] createTicket error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to create ticket. Please try again.',
      detail: error.message,
    });
  }

  return res.status(201).json({
    success: true,
    message: 'Support ticket created successfully',
    ticket: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   GET /api/tickets/user/:userId
   Auth: requireAuth
   Returns tickets for the authenticated user.
───────────────────────────────────────────────────────────────── */
async function getUserTickets(req, res) {
  const requestedUserId = req.params.userId;
  const authenticatedUserId = req.user.id;

  if (requestedUserId !== authenticatedUserId && req.userRole !== 'admin') {
    return res.status(403).json({
      success: false,
      error: 'You can only view your own tickets.',
    });
  }

  const { data, error } = await supabase
    .from('tickets')
    .select('*')
    .eq('user_id', requestedUserId)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('[Tickets] getUserTickets error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to fetch tickets.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    count: data.length,
    tickets: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   GET /api/tickets/admin
   Auth: requireAdmin
   Returns ALL tickets (admin only).
───────────────────────────────────────────────────────────────── */
async function getAllTickets(req, res) {
  const { status, limit = 100, offset = 0 } = req.query;

  let query = supabase
    .from('tickets')
    .select('*')
    .order('created_at', { ascending: false })
    .range(Number(offset), Number(offset) + Number(limit) - 1);

  if (status) {
    query = query.eq('status', status);
  }

  const { data, error } = await query;

  if (error) {
    console.error('[Tickets] getAllTickets error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to fetch tickets.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    count: data.length,
    tickets: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   POST /api/tickets/reply
   Auth: requireAdmin
   Admin replies to a ticket and updates its status.
   Body: { id, admin_reply, status? }  status defaults to 'Replied'
───────────────────────────────────────────────────────────────── */
async function replyToTicket(req, res) {
  const { id, admin_reply, status } = req.body;

  if (!id) {
    return res.status(400).json({
      success: false,
      error: 'Ticket id is required.',
    });
  }

  if (!admin_reply || String(admin_reply).trim().length < 2) {
    return res.status(400).json({
      success: false,
      error: 'admin_reply is required and cannot be empty.',
    });
  }

  // Verify ticket exists
  const { data: existingTicket, error: fetchError } = await supabase
    .from('tickets')
    .select('id, status')
    .eq('id', id)
    .single();

  if (fetchError || !existingTicket) {
    return res.status(404).json({
      success: false,
      error: `Ticket with id ${id} not found.`,
    });
  }

  const allowedStatuses = ['Open', 'Replied', 'Closed'];
  const newStatus = allowedStatuses.includes(status) ? status : 'Replied';

  const { data, error } = await supabase
    .from('tickets')
    .update({
      admin_reply: String(admin_reply).trim(),
      status: newStatus,
    })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('[Tickets] replyToTicket error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to submit reply.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    message: `Ticket #${id} updated with reply`,
    ticket: data,
  });
}

/* ─────────────────────────────────────────────────────────────────
   DELETE /api/tickets/:id
   Auth: requireAdmin
   Hard-deletes a ticket (admin only).
───────────────────────────────────────────────────────────────── */
async function deleteTicket(req, res) {
  const { id } = req.params;

  const { error } = await supabase
    .from('tickets')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('[Tickets] deleteTicket error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to delete ticket.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    message: `Ticket #${id} deleted`,
  });
}

/* ─────────────────────────────────────────────────────────────────
   POST /api/tickets/:id/close
   Auth: requireAdmin or ticket owner
   Closes a ticket.
───────────────────────────────────────────────────────────────── */
async function closeTicket(req, res) {
  const { id } = req.params;

  const { data, error } = await supabase
    .from('tickets')
    .update({ status: 'Closed' })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    console.error('[Tickets] closeTicket error:', error.message);
    return res.status(500).json({
      success: false,
      error: 'Failed to close ticket.',
      detail: error.message,
    });
  }

  return res.status(200).json({
    success: true,
    message: `Ticket #${id} closed`,
    ticket: data,
  });
}

module.exports = {
  createTicket,
  getUserTickets,
  getAllTickets,
  replyToTicket,
  deleteTicket,
  closeTicket,
};
