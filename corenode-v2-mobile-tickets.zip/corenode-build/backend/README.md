# CoreNode Backend API

Production-ready Express.js backend for the CoreNode Hosting Platform.  
Connects to your existing Supabase database and works with the existing frontend.

---

## Quick Start

```bash
# 1. Enter backend folder
cd backend

# 2. Install dependencies
npm install

# 3. Set up environment variables
cp .env.example .env
# → Edit .env and add your SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY

# 4. Start development server (auto-restart on changes)
npm run dev

# 5. Start production server
npm start
```

Server runs at: **http://localhost:5000**

---

## Environment Variables

Create a `.env` file in the `backend/` folder:

```env
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here
PORT=5000
ALLOWED_ORIGINS=http://localhost:5500,http://localhost:3000
```

> ⚠️ The `SUPABASE_SERVICE_ROLE_KEY` bypasses Row Level Security. **Never** expose it in frontend code or commit it to Git.

Get your keys from:  
**Supabase Dashboard → Project Settings → API**

---

## Project Structure

```
backend/
├── server.js                  ← Express app + server start
├── package.json
├── .env.example
├── vercel.json                ← Vercel deployment config
│
├── config/
│   └── supabase.js            ← Supabase service-role client
│
├── routes/
│   ├── auth.js                ← GET /api/me, GET /api/auth/profile/:id
│   ├── orders.js              ← Order CRUD endpoints
│   └── tickets.js             ← Ticket CRUD endpoints
│
├── controllers/
│   ├── ordersController.js    ← Order business logic
│   └── ticketsController.js   ← Ticket business logic
│
└── middleware/
    └── authMiddleware.js      ← JWT verification + admin role check
```

---

## API Reference

All endpoints return JSON. Authenticated endpoints require:

```
Authorization: Bearer <supabase_access_token>
```

Get the token from the Supabase client after login:
```js
const { data } = await supabase.auth.getSession();
const token = data.session.access_token;
```

---

### AUTH

#### `GET /api/me`
Returns the logged-in user's info and role.

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "role": "user",
    "created_at": "2024-01-01T00:00:00Z"
  }
}
```

---

### ORDERS

#### `POST /api/orders/create`
Create a new order after payment submission.

**Headers:** `Authorization: Bearer <token>`  
**Body:**
```json
{
  "plan_name": "Creeper Plan",
  "plan_type": "Minecraft Hosting",
  "price": 299,
  "utr": "416521234567",
  "customer_name": "John Doe",
  "customer_email": "john@example.com"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Order created successfully",
  "order": {
    "id": 1,
    "user_id": "uuid",
    "plan_name": "Creeper Plan",
    "status": "Pending",
    ...
  }
}
```

---

#### `GET /api/orders/user/:userId`
Returns all orders for a specific user.

**Headers:** `Authorization: Bearer <token>`  
**Params:** `userId` – UUID of the user

**Response:**
```json
{
  "success": true,
  "count": 2,
  "orders": [ ... ]
}
```

---

#### `GET /api/orders/admin`
Returns all orders (admin only). Supports filtering.

**Headers:** `Authorization: Bearer <admin_token>`  
**Query params:** `status=Pending`, `limit=50`, `offset=0`

---

#### `POST /api/orders/approve`
Approve an order and set panel credentials.

**Headers:** `Authorization: Bearer <admin_token>`  
**Body:**
```json
{
  "id": 1,
  "panel_link": "https://panel.corenode.in",
  "panel_username": "john_doe",
  "panel_password": "SecurePass123",
  "admin_note": "Server provisioned on Node A"
}
```

---

#### `POST /api/orders/reject`
Reject a pending order.

**Headers:** `Authorization: Bearer <admin_token>`  
**Body:**
```json
{
  "id": 1,
  "admin_note": "Invalid UTR provided"
}
```

---

### TICKETS

#### `POST /api/tickets/create`
Create a new support ticket.

**Headers:** `Authorization: Bearer <token>`  
**Body:**
```json
{
  "subject": "Server not starting",
  "message": "My Minecraft server won't start after the latest update.",
  "order_ref": "42"
}
```

---

#### `GET /api/tickets/user/:userId`
Returns all tickets for a specific user.

**Headers:** `Authorization: Bearer <token>`

---

#### `GET /api/tickets/admin`
Returns all tickets (admin only).

**Headers:** `Authorization: Bearer <admin_token>`  
**Query params:** `status=Open`, `limit=50`, `offset=0`

---

#### `POST /api/tickets/reply`
Admin replies to a ticket.

**Headers:** `Authorization: Bearer <admin_token>`  
**Body:**
```json
{
  "id": 1,
  "admin_reply": "We've restarted your server. Please try again.",
  "status": "Replied"
}
```

---

## Testing with curl

Replace `YOUR_TOKEN` with a real Supabase access token from your browser's localStorage or DevTools.

### Health check
```bash
curl http://localhost:5000/health
```

### Get current user
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:5000/api/me
```

### Create an order
```bash
curl -X POST http://localhost:5000/api/orders/create \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "plan_name": "Creeper Plan",
    "plan_type": "Minecraft Hosting",
    "price": 299,
    "utr": "416521234567",
    "customer_name": "Test User",
    "customer_email": "test@example.com"
  }'
```

### Fetch your orders
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:5000/api/orders/user/YOUR_USER_ID
```

### Create a support ticket
```bash
curl -X POST http://localhost:5000/api/tickets/create \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "subject": "Server issue",
    "message": "My server is not responding to connections."
  }'
```

### Admin: get all orders
```bash
curl -H "Authorization: Bearer ADMIN_TOKEN" \
  http://localhost:5000/api/orders/admin
```

### Admin: approve an order
```bash
curl -X POST http://localhost:5000/api/orders/approve \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "id": 1,
    "panel_link": "https://panel.corenode.in",
    "panel_username": "john123",
    "panel_password": "SecurePass"
  }'
```

### Admin: reply to ticket
```bash
curl -X POST http://localhost:5000/api/tickets/reply \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "id": 1,
    "admin_reply": "Issue resolved. Please check your server now.",
    "status": "Replied"
  }'
```

---

## How to Get Your Auth Token (for testing)

1. Open your frontend in browser and log in
2. Open DevTools → Console
3. Run:
```js
const { data } = await supabase.auth.getSession();
console.log(data.session.access_token);
```
4. Copy the token and use it in curl/Postman

---

## Deployment

### Vercel (recommended for serverless)

```bash
npm install -g vercel
cd backend
vercel

# Set environment variables in Vercel dashboard:
# SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, ALLOWED_ORIGINS
```

`vercel.json` is already included in this project.

---

### Railway

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Select your repo (push `backend/` folder or the whole project)
3. Set root directory to `backend/`
4. Add environment variables:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `PORT` = `5000`
   - `ALLOWED_ORIGINS`
5. Railway auto-detects `npm start` from `package.json`

---

### Render

1. Go to [render.com](https://render.com) → New → Web Service
2. Connect your GitHub repo
3. Set:
   - **Root Directory:** `backend`
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. Add environment variables in Render dashboard

---

## Connecting the Frontend

After deploying, update your frontend `assets/js/supabase.js` or create a config file:

```js
const API_BASE = 'https://your-backend.railway.app'; // or Render/Vercel URL

// Example: create order via backend instead of directly to Supabase
async function createOrderViaBackend(orderData, token) {
  const res = await fetch(`${API_BASE}/api/orders/create`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify(orderData),
  });
  return res.json();
}
```

---

## Security Notes

- The backend uses the **service role key** to bypass Supabase RLS — this is intentional for admin operations and server-side logic
- Regular users are still restricted by JWT verification in `authMiddleware.js`
- Admin endpoints additionally verify `profiles.role = 'admin'`
- Never expose `SUPABASE_SERVICE_ROLE_KEY` in any frontend code
