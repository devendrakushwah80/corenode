/**
 * middleware/authMiddleware.js
 * ─────────────────────────────────────────────────────────────────
 * Two middleware functions:
 *
 *  requireAuth  – verifies the Supabase JWT sent in the Authorization
 *                 header and attaches the decoded user to req.user.
 *
 *  requireAdmin – extends requireAuth; additionally checks that the
 *                 authenticated user has role = 'admin' in the
 *                 profiles table.
 *
 * Usage in routes:
 *   router.get('/protected',  requireAuth,  handler);
 *   router.get('/admin-only', requireAdmin, handler);
 */

const supabase = require('../config/supabase');

/* ─────────────────────────────────────────────────────────────────
   requireAuth
   Expects:  Authorization: Bearer <supabase_access_token>
   Attaches: req.user  = { id, email, ... }
             req.token = raw JWT string
───────────────────────────────────────────────────────────────── */
async function requireAuth(req, res, next) {
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      error: 'Missing or malformed Authorization header. Expected: Bearer <token>',
    });
  }

  const token = authHeader.split(' ')[1];

  // Verify the JWT with Supabase
  const { data, error } = await supabase.auth.getUser(token);

  if (error || !data?.user) {
    return res.status(401).json({
      success: false,
      error: 'Invalid or expired token. Please log in again.',
    });
  }

  req.user  = data.user;
  req.token = token;
  next();
}

/* ─────────────────────────────────────────────────────────────────
   requireAdmin
   Runs requireAuth first, then checks profiles.role = 'admin'.
───────────────────────────────────────────────────────────────── */
async function requireAdmin(req, res, next) {
  // Re-use requireAuth; if it returns an error response, stop here
  await requireAuth(req, res, async () => {
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', req.user.id)
      .single();

    if (error || !profile) {
      return res.status(403).json({
        success: false,
        error: 'Could not verify user role.',
      });
    }

    if (profile.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Access denied. Admin privileges required.',
      });
    }

    req.userRole = 'admin';
    next();
  });
}

module.exports = { requireAuth, requireAdmin };
