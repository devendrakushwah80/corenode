/**
 * server.js
 * ─────────────────────────────────────────────────────────────────
 * CoreNode Hosting Platform – Express.js Backend
 *
 * Entry point. Configures middleware, mounts routes, and starts the
 * HTTP server on PORT (default 5000).
 *
 * Also serves the frontend static files from the parent directory,
 * so you can access the entire platform at http://localhost:5000
 *
 * Run locally:
 *   npm install
 *   npm run dev
 *   npm start
 */

'use strict';

require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const helmet   = require('helmet');
const morgan   = require('morgan');
const path     = require('path');

const app  = express();
const PORT = process.env.PORT || 5000;

const rawOrigins = process.env.ALLOWED_ORIGINS || '';
const allowedOrigins = rawOrigins
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

if (allowedOrigins.length === 0) {
  allowedOrigins.push(
    'http://localhost:3000',
    'http://localhost:5000',
    'http://localhost:5500',
    'http://127.0.0.1:5500',
    'http://127.0.0.1:5000',
    'http://localhost:8080',
    'null'
  );
}

app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: false,
}));

app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (allowedOrigins.includes(origin) || allowedOrigins.includes('*')) {
      return callback(null, true);
    }
    return callback(new Error(`CORS: Origin "${origin}" not allowed`), false);
  },
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
  credentials: true,
  optionsSuccessStatus: 200,
}));

app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

const FRONTEND_DIR = path.resolve(__dirname, '..');

app.use(express.static(FRONTEND_DIR,{
  index:'index.html',
  extensions:['html']
}));

app.get('/health',(req,res)=>{
  res.json({status:'ok',uptime:process.uptime()});
});

const authRoutes    = require('./routes/auth');
const ordersRoutes  = require('./routes/orders');
const ticketsRoutes = require('./routes/tickets');

app.use('/api/auth',authRoutes);
app.use('/api/me',authRoutes);
app.use('/api/orders',ordersRoutes);
app.use('/api/tickets',ticketsRoutes);

app.get('*',(req,res,next)=>{
  if(req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(FRONTEND_DIR,'index.html'));
});

app.use((req,res)=>{
  res.status(404).json({
    success:false,
    error:`Route not found: ${req.method} ${req.originalUrl}`
  });
});

app.use((err,req,res,next)=>{
  console.error('[Server] Unhandled error:',err.message);

  if(err.message && err.message.startsWith('CORS:')){
    return res.status(403).json({success:false,error:err.message});
  }

  res.status(500).json({
    success:false,
    error:'Internal server error',
    detail:process.env.NODE_ENV!=='production'?err.message:undefined
  });
});

app.listen(PORT,()=>{
  console.log('\n╔══════════════════════════════════════════════════╗');
  console.log('║       CoreNode Backend API  –  Running ✅         ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log(`║  Local:   http://localhost:${PORT}                   ║`);
  console.log(`║  Mode:    ${(process.env.NODE_ENV||'development').padEnd(39)}║`);
  console.log('╠══════════════════════════════════════════════════╣');
  console.log('║  Frontend:  http://localhost:5000                ║');
  console.log('║  Dashboard: http://localhost:5000/dashboard.html ║');
  console.log('║  Admin:     http://localhost:5000/admin.html     ║');
  console.log('╠══════════════════════════════════════════════════╣');
  console.log('║  API Endpoints:                                  ║');
  console.log('║   GET  /api/me                                   ║');
  console.log('║   POST /api/orders/create                        ║');
  console.log('║   GET  /api/orders/user/:userId                  ║');
  console.log('║   GET  /api/orders/admin                         ║');
  console.log('║   POST /api/orders/approve                       ║');
  console.log('║   POST /api/orders/reject                        ║');
  console.log('║   POST /api/tickets/create                       ║');
  console.log('║   GET  /api/tickets/user/:userId                 ║');
  console.log('║   GET  /api/tickets/admin                        ║');
  console.log('║   POST /api/tickets/reply                        ║');
  console.log('╚══════════════════════════════════════════════════╝\n');
});

module.exports = app;