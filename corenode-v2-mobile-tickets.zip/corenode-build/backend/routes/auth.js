/**
 * routes/auth.js
 * ─────────────────────────────────────────────────────────────────
 * Authentication routes.
 *
 * GET  /api/me           – Return logged-in user info + profile role
 */

const express = require('express');
const router  = express.Router();
const supabase = require('../config/supabase');
const { requireAuth } = require('../middleware/authMiddleware');

/* ─────────────────────────────────────────────────────────────────
   GET /api/me
   Auth: requireAuth
   Returns the current user's info along with their profile role.
───────────────────────────────────────────────────────────────── */
router.get('/me', requireAuth, async (req, res) => {
  const userId = req.user.id;

  // Fetch profile (role, created_at, etc.)
  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('id, email, role, created_at')
    .eq('id', userId)
    .single();

  if (profileError) {
    // Profile missing is non-fatal — return user without profile
    console.warn('[Auth] profile not found for user:', userId);
  }

  return res.status(200).json({
    success: true,
    user: {
      id:    req.user.id,
      email: req.user.email,
      role:  profile?.role || 'user',
      created_at: profile?.created_at || req.user.created_at,
    },
  });
});

/* ─────────────────────────────────────────────────────────────────
   POST /api/auth/signout
   Auth: requireAuth
   Server-side session invalidation (optional; frontend usually does
   this via supabase.auth.signOut() directly).
───────────────────────────────────────────────────────────────── */
router.post('/signout', requireAuth, async (req, res) => {
  // With JWTs there is no true server-side signout unless using refresh
  // tokens. This endpoint exists as a hook for future session management.
  return res.status(200).json({
    success: true,
    message: 'Signed out. Please clear your token client-side.',
  });
});

/* ─────────────────────────────────────────────────────────────────
   GET /api/auth/profile/:userId
   Auth: requireAuth (own profile) or admin
   Returns profile info for a given userId.
───────────────────────────────────────────────────────────────── */
router.get('/profile/:userId', requireAuth, async (req, res) => {
  const { userId } = req.params;

  // Only allow own profile OR admin
  if (userId !== req.user.id) {
    // Check if requester is admin
    const { data: requesterProfile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', req.user.id)
      .single();

    if (requesterProfile?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'You can only access your own profile.',
      });
    }
  }

  const { data, error } = await supabase
    .from('profiles')
    .select('id, email, role, created_at')
    .eq('id', userId)
    .single();

  if (error || !data) {
    return res.status(404).json({
      success: false,
      error: 'Profile not found.',
    });
  }

  return res.status(200).json({
    success: true,
    profile: data,
  });
});

module.exports = router;
