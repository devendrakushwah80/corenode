/**
 * routes/tickets.js
 * ─────────────────────────────────────────────────────────────────
 * Ticket endpoints:
 *
 *  POST   /api/tickets/create         – Create ticket      (auth)
 *  GET    /api/tickets/user/:userId   – User's own tickets (auth)
 *  GET    /api/tickets/admin          – All tickets        (admin)
 *  POST   /api/tickets/reply          – Admin reply        (admin)
 *  POST   /api/tickets/:id/close      – Close ticket       (auth)
 *  DELETE /api/tickets/:id            – Delete ticket      (admin)
 */

const express = require('express');
const router  = express.Router();
const { requireAuth, requireAdmin } = require('../middleware/authMiddleware');
const {
  createTicket,
  getUserTickets,
  getAllTickets,
  replyToTicket,
  deleteTicket,
  closeTicket,
} = require('../controllers/ticketsController');

// ── User endpoints ────────────────────────────────────────────────
router.post('/create',           requireAuth,  createTicket);
router.get('/user/:userId',      requireAuth,  getUserTickets);
router.post('/:id/close',        requireAuth,  closeTicket);

// ── Admin endpoints ───────────────────────────────────────────────
router.get('/admin',             requireAdmin, getAllTickets);
router.post('/reply',            requireAdmin, replyToTicket);
router.delete('/:id',            requireAdmin, deleteTicket);

module.exports = router;
