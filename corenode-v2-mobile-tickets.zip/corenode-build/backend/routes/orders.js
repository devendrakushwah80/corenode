/**
 * routes/orders.js
 * ─────────────────────────────────────────────────────────────────
 * Order endpoints:
 *
 *  POST /api/orders/create          – Create new order  (auth)
 *  GET  /api/orders/user/:userId    – User's own orders (auth)
 *  GET  /api/orders/admin           – All orders        (admin)
 *  POST /api/orders/approve         – Approve order     (admin)
 *  POST /api/orders/reject          – Reject order      (admin)
 */

const express = require('express');
const router  = express.Router();
const { requireAuth, requireAdmin } = require('../middleware/authMiddleware');
const {
  createOrder,
  getUserOrders,
  getAllOrders,
  approveOrder,
  rejectOrder,
} = require('../controllers/ordersController');

// ── User endpoints ────────────────────────────────────────────────
router.post('/create',          requireAuth,  createOrder);
router.get('/user/:userId',     requireAuth,  getUserOrders);

// ── Admin endpoints ───────────────────────────────────────────────
router.get('/admin',            requireAdmin, getAllOrders);
router.post('/approve',         requireAdmin, approveOrder);
router.post('/reject',          requireAdmin, rejectOrder);

module.exports = router;
