/**
 * config/supabase.js
 * ─────────────────────────────────────────────────────────────────
 * Creates and exports a Supabase client that uses the SERVICE ROLE
 * key so it can bypass Row Level Security (RLS) for admin operations.
 *
 * This client is ONLY used server-side. Never ship the service role
 * key to a browser.
 */

const { createClient } = require('@supabase/supabase-js');

const SUPABASE_URL             = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error(
    '[Supabase] ❌  SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY is missing.\n' +
    '           Copy .env.example → .env and fill in your values.'
  );
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    // Server-side client: disable auto session refresh & persistence
    autoRefreshToken: false,
    persistSession:   false,
    detectSessionInUrl: false,
  },
});

module.exports = supabase;
