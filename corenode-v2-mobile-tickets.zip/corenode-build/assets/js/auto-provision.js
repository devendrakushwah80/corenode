/**
 * CoreNode – AutoProvision
 * ─────────────────────────────────────────────────────────────────
 * Admin order approval pipeline.
 *
 * Priority:
 *   1. Backend API  →  POST /api/orders/approve or /api/orders/reject
 *   2. Direct Supabase update  (fallback when backend is offline)
 *
 * Usage:
 *   await AutoProvision.approve(orderId, { panelLink, username, password, adminNote })
 *   await AutoProvision.reject(orderId, adminNote)
 */

const AutoProvision = (() => {

  const DEFAULT_PANEL = 'https://panel.corenode.in';

  /* ── Credential generators ──────────────────────────────────── */
  function generatePassword(len = 12) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
    const arr   = new Uint32Array(len);
    crypto.getRandomValues(arr);
    return Array.from(arr, n => chars[n % chars.length]).join('');
  }

  function generateUsername(email = '') {
    const base   = email
      ? email.split('@')[0].toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8)
      : 'user';
    const suffix = Math.floor(1000 + Math.random() * 9000);
    return `${base}_${suffix}`;
  }

  /* ── Backend API path ───────────────────────────────────────── */
  async function _approveViaBackend(orderId, opts) {
    const { panelLink, username, password, adminNote } = opts;
    const { data, error } = await API.orders.approve({
      id:             orderId,
      panel_link:     panelLink,
      panel_username: username,
      panel_password: password,
      admin_note:     adminNote || null,
    });
    if (error) throw new Error(error.message || 'Backend approval failed');
    return { success: true, order_id: orderId, email_sent: false, message: data?.message || 'Approved.' };
  }

  /* ── Direct Supabase fallback ───────────────────────────────── */
  async function _approveDirect(orderId, opts) {
    const { panelLink, username, password, adminNote } = opts;
    const { error } = await getSB().from('orders').update({
      status:         'Approved',
      panel_link:     panelLink,
      panel_username: username,
      panel_password: password,
      approved_at:    new Date().toISOString(),
      admin_note:     adminNote || null,
    }).eq('id', orderId);
    if (error) throw new Error(error.message);
    return { success: true, order_id: orderId, email_sent: false, message: 'Order approved (direct DB).' };
  }

  async function _rejectViaBackend(orderId, adminNote) {
    const { data, error } = await API.orders.reject({ id: orderId, admin_note: adminNote || null });
    if (error) throw new Error(error.message || 'Backend rejection failed');
    return { success: true, order_id: orderId, message: data?.message || 'Rejected.' };
  }

  async function _rejectDirect(orderId, adminNote) {
    const { error } = await getSB().from('orders').update({
      status:     'Rejected',
      admin_note: adminNote || null,
    }).eq('id', orderId);
    if (error) throw new Error(error.message);
    return { success: true, order_id: orderId, message: 'Order rejected (direct DB).' };
  }

  /* ── Public: approve ────────────────────────────────────────── */
  async function approve(orderId, opts = {}) {
    const {
      panelLink = DEFAULT_PANEL,
      username  = '',
      password  = '',
      adminNote = '',
    } = opts;

    if (!panelLink || !username || !password) {
      throw new Error('Panel link, username and password are all required.');
    }

    const fullOpts = { panelLink, username, password, adminNote };

    if (typeof API !== 'undefined') {
      try {
        return await _approveViaBackend(orderId, fullOpts);
      } catch (apiErr) {
        console.warn('[AutoProvision] Backend unavailable, falling back to direct DB:', apiErr.message);
      }
    }

    return await _approveDirect(orderId, fullOpts);
  }

  /* ── Public: reject ─────────────────────────────────────────── */
  async function reject(orderId, adminNote = '') {
    if (typeof API !== 'undefined') {
      try {
        return await _rejectViaBackend(orderId, adminNote);
      } catch (apiErr) {
        console.warn('[AutoProvision] Backend unavailable, falling back to direct DB:', apiErr.message);
      }
    }
    return await _rejectDirect(orderId, adminNote);
  }

  return { approve, reject, generatePassword, generateUsername, DEFAULT_PANEL };
})();
