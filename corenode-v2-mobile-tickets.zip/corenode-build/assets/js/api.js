/**
 * CoreNode – Backend API Client
 * ─────────────────────────────────────────────────────────────────
 * All data operations go through the Express backend at API_BASE.
 * This replaces direct Supabase calls from the frontend for orders
 * and tickets, keeping the Supabase anon key usage minimal.
 *
 * Auth: Every request attaches the Supabase JWT (Bearer token)
 * so the backend can verify identity and role.
 *
 * Usage:
 *   const { data, error } = await API.orders.getMyOrders(userId);
 *   const { data, error } = await API.tickets.create({ subject, message });
 */

// If the page is served from the backend (same origin), use relative URLs.
// Otherwise, point to localhost:5000 (for file:// development).
const API_BASE = (
  window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
) ? '' : 'http://localhost:5000';

/* ── Helper: get Supabase JWT from current session ─────────────── */
async function _getToken() {
  try {
    const { data } = await getSB().auth.getSession();
    return data?.session?.access_token || null;
  } catch (e) {
    return null;
  }
}

/* ── Core fetch wrapper ─────────────────────────────────────────── */
async function _apiFetch(path, options = {}) {
  const token = await _getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...(options.headers || {}),
  };

  try {
    const res = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers,
    });

    const json = await res.json();

    if (!res.ok) {
      return { data: null, error: { message: json.error || `HTTP ${res.status}` } };
    }

    return { data: json, error: null };
  } catch (err) {
    return { data: null, error: { message: err.message || 'Network error' } };
  }
}

/* ═══════════════════════════════════════════════════════════════
   API OBJECT — mirrors the DB object shape for easy replacement
═══════════════════════════════════════════════════════════════ */
const API = (() => {

  /* ── Auth ──────────────────────────────────────────────────── */
  const auth = {
    /** Get current logged-in user info from backend */
    getMe: () => _apiFetch('/api/me'),
  };

  /* ── Orders ─────────────────────────────────────────────────── */
  const orders = {
    /**
     * Get orders for a specific user.
     * Returns { data: { orders: [...] }, error }
     */
    getMyOrders: (userId) => _apiFetch(`/api/orders/user/${userId}`),

    /**
     * Get all orders (admin only).
     * Returns { data: { orders: [...] }, error }
     */
    getAllOrders: (status = '') =>
      _apiFetch(`/api/orders/admin${status ? `?status=${status}` : ''}`),

    /**
     * Create a new order.
     * @param {{ plan_name, plan_type, price, utr, customer_name, customer_email }} payload
     */
    create: (payload) =>
      _apiFetch('/api/orders/create', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),

    /**
     * Approve an order (admin).
     * @param {{ id, panel_link, panel_username, panel_password, admin_note? }} payload
     */
    approve: (payload) =>
      _apiFetch('/api/orders/approve', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),

    /**
     * Reject an order (admin).
     * @param {{ id, admin_note? }} payload
     */
    reject: (payload) =>
      _apiFetch('/api/orders/reject', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),
  };

  /* ── Tickets ────────────────────────────────────────────────── */
  const tickets = {
    /**
     * Get tickets for a specific user.
     * Returns { data: { tickets: [...] }, error }
     */
    getMyTickets: (userId) => _apiFetch(`/api/tickets/user/${userId}`),

    /**
     * Get all tickets (admin only).
     */
    getAllTickets: (status = '') =>
      _apiFetch(`/api/tickets/admin${status ? `?status=${status}` : ''}`),

    /**
     * Create a new support ticket.
     * @param {{ subject, message, order_ref? }} payload
     */
    create: (payload) =>
      _apiFetch('/api/tickets/create', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),

    /**
     * Admin reply to a ticket.
     * @param {{ id, admin_reply, status? }} payload
     */
    reply: (payload) =>
      _apiFetch('/api/tickets/reply', {
        method: 'POST',
        body: JSON.stringify(payload),
      }),

    /**
     * Close a ticket.
     */
    close: (id) =>
      _apiFetch(`/api/tickets/${id}/close`, { method: 'POST' }),

    /**
     * Delete a ticket (admin).
     */
    delete: (id) =>
      _apiFetch(`/api/tickets/${id}`, { method: 'DELETE' }),
  };

  return { auth, orders, tickets };
})();

/* ═══════════════════════════════════════════════════════════════
   DB SHIM — overrides the DB object from supabase.js with
   backend-API equivalents so existing code requires no changes.

   Call DB_connectBackend() after the page loads to switch over.
   Pages that haven't loaded supabase.js yet will skip this.
═══════════════════════════════════════════════════════════════ */

/**
 * Patch DB.getMyOrders / DB.getMyTickets etc. to go through the
 * backend API instead of direct Supabase queries.
 *
 * Shape of every method is kept compatible:
 *   returns { data, error }
 * where data is the raw array (not the response envelope).
 */
function DB_connectBackend() {
  if (typeof DB === 'undefined') return;

  /* Orders */
  DB.getMyOrders = async (userId) => {
    const { data, error } = await API.orders.getMyOrders(userId);
    return { data: data?.orders || [], error };
  };

  DB.getAllOrders = async () => {
    const { data, error } = await API.orders.getAllOrders();
    return { data: data?.orders || [], error };
  };

  DB.insertOrder = async (order) => {
    const { data, error } = await API.orders.create(order);
    return { data: data?.order || null, error };
  };

  /* Tickets */
  DB.getMyTickets = async (userId) => {
    const { data, error } = await API.tickets.getMyTickets(userId);
    return { data: data?.tickets || [], error };
  };

  DB.getAllTickets = async () => {
    const { data, error } = await API.tickets.getAllTickets();
    return { data: data?.tickets || [], error };
  };

  DB.insertTicket = async (ticket) => {
    const { data, error } = await API.tickets.create(ticket);
    return { data: data?.ticket || null, error };
  };

  DB.updateTicket = async (id, updates) => {
    if (updates.admin_reply !== undefined) {
      const { data, error } = await API.tickets.reply({ id, ...updates });
      return { data: data?.ticket || null, error };
    }
    if (updates.status === 'Closed') {
      const { data, error } = await API.tickets.close(id);
      return { data: data?.ticket || null, error };
    }
    return { data: null, error: null };
  };

  DB.deleteTicket = async (id) => {
    return API.tickets.delete(id);
  };

  console.log('[API] DB shim connected — all data goes through backend API');
}
