/**
 * CoreNode – Checkout System
 * ─────────────────────────────────────────────────────────────────
 * Order creation priority:
 *   1. Backend API  →  POST /api/orders/create  (when user is logged in)
 *   2. Direct Supabase  →  DB.insertOrder()     (fallback)
 *   3. localStorage                             (last resort / offline)
 */

const Checkout = (() => {

  /* ── Settings (QR / UPI) ──────────────────────────────────────── */
  async function _getSettings() {
    if (typeof DB !== 'undefined') {
      try {
        const { data, error } = await DB.getSettings();
        if (!error && data) return data;
      } catch (e) {}
    }
    try { return JSON.parse(localStorage.getItem('cna_settings') || '{}'); }
    catch (e) { return {}; }
  }

  /* ── Open / Close ─────────────────────────────────────────────── */
  function open() {
    _ensureModal();
    _populateQR();
    _populateOrderSummary();
    _clearForm();
    const overlay = document.getElementById('checkout-overlay');
    if (overlay) { overlay.classList.add('open'); document.body.style.overflow = 'hidden'; }
  }

  function close() {
    const overlay = document.getElementById('checkout-overlay');
    if (overlay) { overlay.classList.remove('open'); document.body.style.overflow = ''; }
  }

  /* ── Form helpers ─────────────────────────────────────────────── */
  function _clearForm() {
    ['checkout-name', 'checkout-email', 'checkout-utr'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.value = '';
    });
    if (typeof AuthManager !== 'undefined' && AuthManager.isLoggedIn()) {
      const emailEl = document.getElementById('checkout-email');
      if (emailEl) emailEl.value = AuthManager.getUserEmail();
    }
    const notice    = document.getElementById('checkout-notice');
    const submitBtn = document.getElementById('checkout-submit');
    if (notice)    notice.classList.add('hidden');
    if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Submit Payment'; submitBtn.classList.remove('hidden'); }
  }

  async function _populateQR() {
    const settings = await _getSettings();
    const qrImg = document.getElementById('checkout-qr');
    const upiEl = document.getElementById('checkout-upi');
    if (qrImg) {
      qrImg.src = settings.qr_image || settings.qrImage || 'assets/images/payment-qr.png';
      qrImg.onerror = () => { qrImg.src = 'assets/images/payment-qr.png'; };
    }
    if (upiEl) upiEl.textContent = settings.upi_id || settings.upiId || 'payments@corenode.in';
  }

  function _populateOrderSummary() {
    if (typeof Cart === 'undefined') return;
    const items = Cart.getAll();
    const total = Cart.getTotal();
    const el    = document.getElementById('checkout-summary');
    if (!el) return;
    if (!items.length) {
      el.innerHTML = '<p style="font-size:0.85rem;color:var(--text-muted)">No items in cart.</p>';
      return;
    }
    el.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:0.4rem;margin-bottom:0.75rem">
        ${items.map(i => `
          <div style="display:flex;justify-content:space-between;align-items:center;font-size:0.82rem;color:var(--text-secondary)">
            <span>${_esc(i.name)} <span style="color:var(--text-muted);font-size:0.75rem">(${_esc(i.type)})</span></span>
            <span style="font-weight:600;color:var(--text-primary)">₹${Number(i.price).toLocaleString('en-IN')}</span>
          </div>`).join('')}
      </div>
      <div style="display:flex;justify-content:space-between;padding-top:0.6rem;border-top:1px solid var(--border);font-weight:700;font-size:0.9rem">
        <span>Total</span>
        <span style="color:var(--accent)">₹${total.toLocaleString('en-IN')}</span>
      </div>`;
  }

  /* ── Submit ───────────────────────────────────────────────────── */
  async function _handleSubmit(e) {
    e && e.preventDefault();

    const name  = (document.getElementById('checkout-name')?.value  || '').trim();
    const email = (document.getElementById('checkout-email')?.value || '').trim();
    const utr   = (document.getElementById('checkout-utr')?.value   || '').trim();

    if (!name)  return _toast('Please enter your full name', 'error');
    if (!email || !_validEmail(email)) return _toast('Please enter a valid email address', 'error');
    if (!utr || utr.length < 6) return _toast('Please enter a valid UTR / Transaction ID', 'error');

    const items = (typeof Cart !== 'undefined') ? Cart.getAll() : [];
    if (!items.length) return _toast('Your cart is empty', 'error');

    const submitBtn = document.getElementById('checkout-submit');
    if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Submitting…'; }

    const userId = (typeof AuthManager !== 'undefined' && AuthManager.getUserId()) || null;
    let allOk = true;

    for (const item of items) {
      const payload = {
        user_id:        userId,
        plan_name:      item.name,
        plan_type:      item.type || null,
        price:          item.price,
        utr,
        customer_name:  name,
        customer_email: email,
        status:         'Pending',
        panel_link:     null,
        panel_username: null,
        panel_password: null,
      };

      const ok = await _createOrder(payload);
      if (!ok) allOk = false;
    }

    localStorage.setItem('cna_last_email', email);
    if (typeof Cart !== 'undefined') Cart.clear();

    const notice = document.getElementById('checkout-notice');
    if (notice)    notice.classList.remove('hidden');
    if (submitBtn) submitBtn.classList.add('hidden');

    _toast(allOk ? 'Payment submitted! Redirecting…' : 'Submitted (offline mode)', 'success');

    setTimeout(() => {
      if (typeof AuthManager !== 'undefined' && AuthManager.isLoggedIn()) {
        window.location.href = 'dashboard.html';
      } else {
        window.location.href = 'orders.html';
      }
    }, 1800);
  }

  /* ── Order creation: API → Supabase → localStorage ─────────── */
  async function _createOrder(payload) {
    // 1. Backend API (preferred — saves to DB with JWT auth)
    if (typeof API !== 'undefined' && payload.user_id) {
      const { data, error } = await API.orders.create(payload);
      if (!error) {
        console.log('[Checkout] Order saved via backend API, id:', data?.order?.id);
        return true;
      }
      console.warn('[Checkout] Backend failed:', error.message, '— trying direct Supabase');
    }

    // 2. Direct Supabase insert
    if (typeof getSB === 'function') {
      try {
        const { data, error } = await getSB().from('orders').insert([payload]).select().single();
        if (!error) {
          console.log('[Checkout] Order saved via direct Supabase, id:', data?.id);
          return true;
        }
        console.warn('[Checkout] Supabase insert failed:', error.message);
      } catch (err) {
        console.warn('[Checkout] Supabase threw:', err.message);
      }
    }

    // 3. localStorage fallback
    _saveLocal({ ...payload, orderId: _genId(), createdAt: new Date().toISOString() });
    console.warn('[Checkout] Order saved to localStorage (offline fallback)');
    return false;
  }

  function _saveLocal(order) {
    try {
      const orders = JSON.parse(localStorage.getItem('cna_orders') || '[]');
      orders.unshift(order);
      localStorage.setItem('cna_orders', JSON.stringify(orders));
    } catch (e) {}
  }

  function _genId() {
    return `CNA-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
  }

  /* ── Modal HTML ───────────────────────────────────────────────── */
  function _ensureModal() {
    if (document.getElementById('checkout-overlay')) return;

    document.body.insertAdjacentHTML('beforeend', `
<div id="checkout-overlay" class="modal-overlay" role="dialog" aria-modal="true" aria-label="Checkout">
  <div class="modal checkout-modal">
    <div class="modal-header">
      <h3>Complete Payment</h3>
      <button class="modal-close" id="checkout-close" aria-label="Close">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>
    <div class="modal-body">
      <div style="margin-bottom:1.25rem">
        <div class="form-label" style="margin-bottom:0.5rem">Order Summary</div>
        <div id="checkout-summary" style="background:var(--bg-base);border:1px solid var(--border);border-radius:var(--radius);padding:0.85rem"></div>
      </div>
      <div class="qr-box">
        <img id="checkout-qr" src="assets/images/payment-qr.png" alt="Payment QR Code"/>
        <div class="form-label" style="margin:0">UPI ID</div>
        <div class="qr-upi" id="checkout-upi">payments@corenode.in</div>
      </div>
      <div class="steps">
        <div class="step"><div class="step-num">1</div><span>Scan QR code or copy UPI ID above</span></div>
        <div class="step"><div class="step-num">2</div><span>Complete the payment in your UPI app</span></div>
        <div class="step"><div class="step-num">3</div><span>Enter the UTR / Transaction ID below and submit</span></div>
      </div>
      <div class="form-group">
        <label class="form-label" for="checkout-name">Full Name</label>
        <input class="form-input" id="checkout-name" type="text" placeholder="Your full name" autocomplete="name"/>
      </div>
      <div class="form-group">
        <label class="form-label" for="checkout-email">Email Address</label>
        <input class="form-input" id="checkout-email" type="email" placeholder="you@example.com" autocomplete="email"/>
      </div>
      <div class="form-group">
        <label class="form-label" for="checkout-utr">Transaction ID / UTR Number</label>
        <input class="form-input" id="checkout-utr" type="text" placeholder="e.g. 416521234567" autocomplete="off"/>
      </div>
      <div id="checkout-notice" class="alert alert-success hidden" role="alert">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" style="flex-shrink:0">
          <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <div>
          <div style="font-weight:600;margin-bottom:0.2rem">Payment submitted successfully!</div>
          <div style="font-size:0.82rem;opacity:0.85">Redirecting to your dashboard…</div>
        </div>
      </div>
      <button id="checkout-submit" class="btn btn-primary btn-full btn-lg">Submit Payment</button>
    </div>
  </div>
</div>`);

    document.getElementById('checkout-close')?.addEventListener('click', close);
    document.getElementById('checkout-overlay')?.addEventListener('click', e => {
      if (e.target.id === 'checkout-overlay') close();
    });
    document.getElementById('checkout-submit')?.addEventListener('click', _handleSubmit);
  }

  /* ── Helpers ──────────────────────────────────────────────────── */
  function _validEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
  function _esc(s) { const d = document.createElement('div'); d.appendChild(document.createTextNode(s || '')); return d.innerHTML; }
  function _toast(msg, type) {
    if (typeof Cart !== 'undefined' && Cart.showToast) Cart.showToast(msg, type);
    else alert(msg);
  }

  return { open, close };
})();
